FORM-CHU-VIET-TAY-2
Mở index.html trong trình duyệt. Nét vector tái tạo gần đúng theo ảnh mẫu, không phải font gốc. Hỗ trợ tiếng Việt, nền hồng trơn, hai mẫu nội dung, chỉnh màu và xuất PNG.
