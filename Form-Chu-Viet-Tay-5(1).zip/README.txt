Form-Chu-Viet-Tay-5
Mở index.html để nhập chữ, đổi màu, căn chỉnh và xuất PNG.
Nét vector tái tạo gần đúng ảnh mẫu, không phải font gốc.
