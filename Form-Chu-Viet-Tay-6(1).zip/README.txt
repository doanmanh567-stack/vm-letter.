Form-Chu-Viet-Tay-6
Mở index.html trong trình duyệt để nhập chữ, đổi màu, chỉnh cỡ và xuất PNG.
Nét vector mô phỏng ảnh mẫu; không phải font gốc.
