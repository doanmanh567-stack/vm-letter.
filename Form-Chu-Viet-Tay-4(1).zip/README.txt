Form-Chu-Viet-Tay-4
Mở index.html để nhập chữ, đổi màu, căn chỉnh và xuất PNG. Bộ nét vector tái tạo gần đúng từ ảnh, không phải font gốc.
