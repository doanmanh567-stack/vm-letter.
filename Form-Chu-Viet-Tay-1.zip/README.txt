Bản form chữ viết tay 1

- Tái tạo theo 2 ảnh mẫu mới người dùng gửi.
- Nền trắng, chữ đen, hỗ trợ tiếng Việt có dấu.
- Có 2 nút mẫu tương ứng 2 ảnh tham chiếu.
- Có thể đổi nội dung, màu nền, màu chữ, cỡ chữ, khoảng cách dòng và xuất PNG.

Mở file index.html trên điện thoại hoặc máy tính để sử dụng.
