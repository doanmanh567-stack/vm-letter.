Form-Chu-Viet-Tay-3
Mở index.html để nhập nội dung, đổi màu, chỉnh kích thước và xuất PNG 1152 × 1307.
Bộ chữ vector tái tạo gần đúng từ ảnh IMG_2443, không phải font gốc TTF.
